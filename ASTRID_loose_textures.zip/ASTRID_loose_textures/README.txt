ASTRID v4 — loose texture assets

These are the five PNG textures included in astrid_textures_v4.zip, extracted as loose files.
They are not a modified RPF and do not include the ASTRID logo or particle-effect configuration.

Files:
- ptfx_multi_sheet_003_debris.png
- ptfx_muzzle_01.png
- ptfx_muzzle_core_rgb.png
- ptfx_smoke_wispy_anim.png
- ptfx_starbursts_rgb.png

Merge note: do not replace AGX textures by name alone unless the corresponding texture dictionary / particle references match. The effect behaviour (burst direction/velocity) is controlled by particle effect data, not by these PNGs alone.
