using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Threading;

namespace DynamicIsland.Services;

/// <summary>
/// Detects Caps Lock presses anywhere in Windows with a low-level keyboard hook.
/// It only looks at the Caps Lock key; nothing else is read or stored.
/// </summary>
public sealed class CapsLockWatcher : IDisposable
{
    private delegate IntPtr HookProc(int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int idHook, HookProc proc, IntPtr hMod, uint threadId);

    [DllImport("user32.dll")]
    private static extern bool UnhookWindowsHookEx(IntPtr hook);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hook, int nCode, IntPtr wParam, IntPtr lParam);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr GetModuleHandle(string? name);

    [DllImport("user32.dll")]
    private static extern short GetKeyState(int virtualKey);

    private const int WH_KEYBOARD_LL = 13;
    private const int VK_CAPITAL = 0x14;
    private const int WM_KEYDOWN = 0x0100, WM_KEYUP = 0x0101, WM_SYSKEYDOWN = 0x0104, WM_SYSKEYUP = 0x0105;

    private readonly Dispatcher _ui;
    private readonly HookProc _proc; // keep a reference so the GC doesn't collect it
    private IntPtr _hook;
    private bool _isOn, _held;

    public CapsLockWatcher(Dispatcher ui)
    {
        _ui = ui;
        _proc = HookCallback;
    }

    /// <summary>Raised on the UI thread with the new Caps Lock state.</summary>
    public event Action<bool>? Changed;

    public void Start()
    {
        _isOn = (GetKeyState(VK_CAPITAL) & 1) != 0;
        using var module = Process.GetCurrentProcess().MainModule;
        _hook = SetWindowsHookEx(WH_KEYBOARD_LL, _proc, GetModuleHandle(module?.ModuleName), 0);
    }

    private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
    {
        if (nCode >= 0)
        {
            int vk = Marshal.ReadInt32(lParam);
            if (vk == VK_CAPITAL)
            {
                int msg = (int)wParam;
                if ((msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN) && !_held)
                {
                    _held = true;
                    _isOn = !_isOn;
                    bool state = _isOn;
                    _ui.InvokeAsync(() => Changed?.Invoke(state)); // queued, so the hook never blocks
                }
                else if (msg == WM_KEYUP || msg == WM_SYSKEYUP)
                {
                    _held = false;
                }
            }
        }
        return CallNextHookEx(_hook, nCode, wParam, lParam);
    }

    public void Dispose()
    {
        if (_hook != IntPtr.Zero)
        {
            UnhookWindowsHookEx(_hook);
            _hook = IntPtr.Zero;
        }
    }
}
