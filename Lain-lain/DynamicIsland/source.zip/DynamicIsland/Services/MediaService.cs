using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Windows.Media.Control;

namespace DynamicIsland.Services;

/// <summary>
/// Watches whatever is playing in Windows (Spotify, browsers, Media Player...)
/// and exposes track info, album art, progress and controls.
/// All events are raised on the UI thread.
/// </summary>
public sealed class MediaService
{
    public static readonly Color DefaultAccent = Color.FromRgb(0x30, 0xD1, 0x58);

    private readonly Dispatcher _ui;
    private GlobalSystemMediaTransportControlsSessionManager? _manager;
    private GlobalSystemMediaTransportControlsSession? _session;

    private TimeSpan _start, _position, _duration;
    private DateTimeOffset _positionUpdated = DateTimeOffset.Now;
    private string _lastTrackKey = "";

    public MediaService(Dispatcher ui) => _ui = ui;

    public bool HasSession => _session != null;
    public bool IsPlaying { get; private set; }
    public string Title { get; private set; } = "";
    public string Artist { get; private set; } = "";
    public string AppId { get; private set; } = "";
    public BitmapSource? Art { get; private set; }
    public Color Accent { get; private set; } = DefaultAccent;
    public TimeSpan Duration => _duration;
    public bool HasTimeline => _duration > TimeSpan.FromSeconds(1);

    /// <summary>Current position, estimated between the app's updates.</summary>
    public TimeSpan Position
    {
        get
        {
            var p = _position;
            if (IsPlaying) p += DateTimeOffset.Now - _positionUpdated;
            if (p < TimeSpan.Zero) p = TimeSpan.Zero;
            if (_duration > TimeSpan.Zero && p > _duration) p = _duration;
            return p;
        }
    }

    /// <summary>Anything changed (track, play state, progress, app).</summary>
    public event Action? StateChanged;

    /// <summary>A different song started.</summary>
    public event Action? TrackChanged;

    public async Task StartAsync()
    {
        try
        {
            _manager = await GlobalSystemMediaTransportControlsSessionManager.RequestAsync();
            _manager.CurrentSessionChanged += (_, _) => _ui.InvokeAsync(Attach);
            Attach();
        }
        catch
        {
            StateChanged?.Invoke();
        }
    }

    public async Task TogglePlayPauseAsync()
    {
        if (_session != null) await _session.TryTogglePlayPauseAsync();
    }

    public async Task NextAsync()
    {
        if (_session != null) await _session.TrySkipNextAsync();
    }

    public async Task PreviousAsync()
    {
        if (_session != null) await _session.TrySkipPreviousAsync();
    }

    public async Task SeekAsync(TimeSpan position)
    {
        if (_session == null || !HasTimeline) return;
        _position = position;
        _positionUpdated = DateTimeOffset.Now;
        try { await _session.TryChangePlaybackPositionAsync((_start + position).Ticks); }
        catch { /* some apps don't support seeking */ }
    }

    // ------------------------------------------------------------------

    private void Attach()
    {
        if (_session != null)
        {
            _session.MediaPropertiesChanged -= OnMediaPropertiesChanged;
            _session.PlaybackInfoChanged -= OnPlaybackInfoChanged;
            _session.TimelinePropertiesChanged -= OnTimelineChanged;
        }

        _session = _manager?.GetCurrentSession();

        if (_session == null)
        {
            Clear();
            StateChanged?.Invoke();
            return;
        }

        _session.MediaPropertiesChanged += OnMediaPropertiesChanged;
        _session.PlaybackInfoChanged += OnPlaybackInfoChanged;
        _session.TimelinePropertiesChanged += OnTimelineChanged;

        AppId = _session.SourceAppUserModelId ?? "";
        ReadPlayback();
        ReadTimeline();
        StateChanged?.Invoke();
        _ = ReadPropertiesAsync();
    }

    // WinRT raises these on background threads, so hop to the UI thread
    private void OnMediaPropertiesChanged(GlobalSystemMediaTransportControlsSession sender, MediaPropertiesChangedEventArgs args)
        => _ui.InvokeAsync(ReadPropertiesAsync);

    private void OnPlaybackInfoChanged(GlobalSystemMediaTransportControlsSession sender, PlaybackInfoChangedEventArgs args)
        => _ui.InvokeAsync(() => { ReadPlayback(); StateChanged?.Invoke(); });

    private void OnTimelineChanged(GlobalSystemMediaTransportControlsSession sender, TimelinePropertiesChangedEventArgs args)
        => _ui.InvokeAsync(() => { ReadTimeline(); StateChanged?.Invoke(); });

    private void ReadPlayback()
    {
        try
        {
            var info = _session?.GetPlaybackInfo();
            bool playing = info?.PlaybackStatus == GlobalSystemMediaTransportControlsSessionPlaybackStatus.Playing;
            if (playing != IsPlaying)
            {
                // Freeze the estimated position at the moment the state flips
                _position = Position;
                _positionUpdated = DateTimeOffset.Now;
                IsPlaying = playing;
            }
        }
        catch { }
    }

    private void ReadTimeline()
    {
        try
        {
            var t = _session?.GetTimelineProperties();
            if (t == null) return;

            _start = t.StartTime;
            _duration = t.EndTime - t.StartTime;
            _position = t.Position - t.StartTime;

            // Some apps report a bogus "last updated" time
            var updated = t.LastUpdatedTime;
            _positionUpdated = updated.Year < 2000 || updated > DateTimeOffset.Now ? DateTimeOffset.Now : updated;
        }
        catch { }
    }

    private async Task ReadPropertiesAsync()
    {
        var session = _session;
        if (session == null) return;

        try
        {
            var props = await session.TryGetMediaPropertiesAsync();
            if (session != _session) return; // switched apps while waiting

            Title = props.Title ?? "";
            Artist = string.IsNullOrWhiteSpace(props.Artist) ? props.AlbumArtist ?? "" : props.Artist;

            Art = props.Thumbnail != null ? await LoadThumbnailAsync(props.Thumbnail) : null;
            if (session != _session) return;

            Accent = Art != null ? ColorExtractor.GetAccent(Art, DefaultAccent) : DefaultAccent;

            string key = Title + "|" + Artist;
            bool isNewTrack = key != _lastTrackKey && !string.IsNullOrWhiteSpace(Title);
            _lastTrackKey = key;

            StateChanged?.Invoke();
            if (isNewTrack) TrackChanged?.Invoke();
        }
        catch
        {
            // Players briefly report nothing while switching tracks
        }
    }

    private static async Task<BitmapSource?> LoadThumbnailAsync(global::Windows.Storage.Streams.IRandomAccessStreamReference reference)
    {
        try
        {
            using var winStream = await reference.OpenReadAsync();
            using var stream = winStream.AsStreamForRead();
            var memory = new MemoryStream();
            await stream.CopyToAsync(memory);
            memory.Position = 0;

            var bitmap = new BitmapImage();
            bitmap.BeginInit();
            bitmap.CacheOption = BitmapCacheOption.OnLoad;
            bitmap.DecodePixelWidth = 200;
            bitmap.StreamSource = memory;
            bitmap.EndInit();
            bitmap.Freeze();
            return bitmap;
        }
        catch
        {
            return null;
        }
    }

    private void Clear()
    {
        Title = "";
        Artist = "";
        AppId = "";
        Art = null;
        Accent = DefaultAccent;
        IsPlaying = false;
        _duration = TimeSpan.Zero;
        _position = TimeSpan.Zero;
        _lastTrackKey = "";
    }
}
