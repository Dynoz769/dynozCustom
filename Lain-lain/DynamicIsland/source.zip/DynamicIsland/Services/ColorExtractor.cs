using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DynamicIsland.Services;

/// <summary>Picks a bright, vivid colour from album art (used for the equaliser and seek bar).</summary>
internal static class ColorExtractor
{
    public static Color GetAccent(BitmapSource source, Color fallback)
    {
        try
        {
            BitmapSource small = source;
            double scale = 32.0 / Math.Max(source.PixelWidth, source.PixelHeight);
            if (scale < 1) small = new TransformedBitmap(source, new ScaleTransform(scale, scale));

            var bgra = new FormatConvertedBitmap(small, PixelFormats.Bgra32, null, 0);
            int w = bgra.PixelWidth, h = bgra.PixelHeight;
            var px = new byte[w * h * 4];
            bgra.CopyPixels(px, w * 4, 0);

            double rSum = 0, gSum = 0, bSum = 0, weightSum = 0;
            for (int i = 0; i < px.Length; i += 4)
            {
                byte b = px[i], g = px[i + 1], r = px[i + 2], a = px[i + 3];
                if (a < 128) continue;

                int max = Math.Max(r, Math.Max(g, b));
                int min = Math.Min(r, Math.Min(g, b));
                double value = max / 255.0;
                double saturation = max == 0 ? 0 : (max - min) / (double)max;

                // Favour colourful, not-too-dark pixels
                double weight = saturation * saturation * value + 0.01;
                rSum += r * weight; gSum += g * weight; bSum += b * weight; weightSum += weight;
            }

            if (weightSum <= 0) return fallback;

            double rr = rSum / weightSum, gg = gSum / weightSum, bb = bSum / weightSum;
            double top = Math.Max(rr, Math.Max(gg, bb));
            double bottom = Math.Min(rr, Math.Min(gg, bb));
            if (top < 1) return fallback;

            // Mostly grey artwork: use soft white
            if (top - bottom < 25) return Color.FromRgb(235, 235, 235);

            // Brighten so it stands out on pure black
            double k = 240 / top;
            return Color.FromRgb(
                (byte)Math.Clamp(rr * k, 0, 255),
                (byte)Math.Clamp(gg * k, 0, 255),
                (byte)Math.Clamp(bb * k, 0, 255));
        }
        catch
        {
            return fallback;
        }
    }
}
