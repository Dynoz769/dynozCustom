using System.Windows.Threading;
using Windows.System.Power;

namespace DynamicIsland.Services;

/// <summary>Battery level and charger events. Events are raised on the UI thread.</summary>
public sealed class PowerService
{
    private readonly Dispatcher _ui;

    public PowerService(Dispatcher ui) => _ui = ui;

    public event Action? PluggedChanged;
    public event Action? PercentChanged;

    public bool HasBattery
    {
        get { try { return PowerManager.BatteryStatus != BatteryStatus.NotPresent; } catch { return false; } }
    }

    public int Percent
    {
        get { try { return PowerManager.RemainingChargePercent; } catch { return 0; } }
    }

    public bool IsCharging
    {
        get { try { return PowerManager.BatteryStatus == BatteryStatus.Charging; } catch { return false; } }
    }

    public bool IsPluggedIn
    {
        get { try { return PowerManager.PowerSupplyStatus != PowerSupplyStatus.NotPresent; } catch { return true; } }
    }

    public void Start()
    {
        try
        {
            PowerManager.PowerSupplyStatusChanged += (_, _) => _ui.InvokeAsync(() => PluggedChanged?.Invoke());
            PowerManager.RemainingChargePercentChanged += (_, _) => _ui.InvokeAsync(() => PercentChanged?.Invoke());
            PowerManager.BatteryStatusChanged += (_, _) => _ui.InvokeAsync(() => PercentChanged?.Invoke());
        }
        catch { }
    }
}
