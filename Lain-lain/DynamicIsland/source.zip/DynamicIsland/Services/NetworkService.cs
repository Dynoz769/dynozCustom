using System.Windows.Threading;
using Windows.Networking.Connectivity;

namespace DynamicIsland.Services;

/// <summary>Reports Wi-Fi / Ethernet connect and disconnect. Events are raised on the UI thread.</summary>
public sealed class NetworkService
{
    private readonly Dispatcher _ui;
    private readonly DispatcherTimer _debounce;
    private string _lastKey = "";
    private bool _initialised;

    public NetworkService(Dispatcher ui)
    {
        _ui = ui;
        // Windows fires several events while a connection settles; wait for it to calm down
        _debounce = new DispatcherTimer(DispatcherPriority.Normal, ui) { Interval = TimeSpan.FromMilliseconds(1200) };
        _debounce.Tick += (_, _) => { _debounce.Stop(); Read(); };
    }

    /// <summary>(connected, network name, is Wi-Fi)</summary>
    public event Action<bool, string, bool>? Changed;

    public void Start()
    {
        Read();
        _initialised = true;
        try
        {
            NetworkInformation.NetworkStatusChanged += _ => _ui.InvokeAsync(() =>
            {
                _debounce.Stop();
                _debounce.Start();
            });
        }
        catch { }
    }

    private void Read()
    {
        bool connected = false, wifi = false;
        string name = "";

        try
        {
            var profile = NetworkInformation.GetInternetConnectionProfile();
            if (profile != null && profile.GetNetworkConnectivityLevel() != NetworkConnectivityLevel.None)
            {
                connected = true;
                wifi = profile.IsWlanConnectionProfile;
                name = wifi
                    ? profile.WlanConnectionProfileDetails?.GetConnectedSsid() ?? profile.ProfileName
                    : profile.ProfileName;
            }
        }
        catch { }

        string key = $"{connected}|{name}";
        if (key == _lastKey) return;
        _lastKey = key;

        if (_initialised) Changed?.Invoke(connected, name, wifi);
    }
}
