using System.Net.NetworkInformation;
using System.Runtime.InteropServices;

namespace DynamicIsland.Services;

/// <summary>CPU, memory and network speed. Call Sample() once per second.</summary>
public sealed class SystemMonitor
{
    [DllImport("kernel32.dll")]
    private static extern bool GetSystemTimes(out long idle, out long kernel, out long user);

    [StructLayout(LayoutKind.Sequential)]
    private struct MEMORYSTATUSEX
    {
        public uint dwLength;
        public uint dwMemoryLoad;
        public ulong ullTotalPhys;
        public ulong ullAvailPhys;
        public ulong ullTotalPageFile;
        public ulong ullAvailPageFile;
        public ulong ullTotalVirtual;
        public ulong ullAvailVirtual;
        public ulong ullAvailExtendedVirtual;
    }

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern bool GlobalMemoryStatusEx(ref MEMORYSTATUSEX status);

    private long _lastIdle, _lastKernel, _lastUser;
    private long _lastRx, _lastTx;
    private DateTime _lastNetSample;
    private bool _primed;

    public double CpuPercent { get; private set; }
    public double MemoryPercent { get; private set; }
    public double MemoryUsedGb { get; private set; }
    public double MemoryTotalGb { get; private set; }
    public double DownloadBytesPerSec { get; private set; }
    public double UploadBytesPerSec { get; private set; }

    public void Sample()
    {
        SampleCpu();
        SampleMemory();
        SampleNetwork();
        _primed = true;
    }

    private void SampleCpu()
    {
        if (!GetSystemTimes(out long idle, out long kernel, out long user)) return;

        if (_primed)
        {
            long idleDelta = idle - _lastIdle;
            long total = (kernel - _lastKernel) + (user - _lastUser); // kernel time includes idle
            if (total > 0) CpuPercent = Math.Clamp((total - idleDelta) * 100.0 / total, 0, 100);
        }

        _lastIdle = idle; _lastKernel = kernel; _lastUser = user;
    }

    private void SampleMemory()
    {
        var status = new MEMORYSTATUSEX { dwLength = (uint)Marshal.SizeOf<MEMORYSTATUSEX>() };
        if (!GlobalMemoryStatusEx(ref status)) return;

        const double GB = 1024.0 * 1024 * 1024;
        MemoryTotalGb = status.ullTotalPhys / GB;
        MemoryUsedGb = (status.ullTotalPhys - status.ullAvailPhys) / GB;
        MemoryPercent = status.dwMemoryLoad;
    }

    private void SampleNetwork()
    {
        long rx = 0, tx = 0;
        try
        {
            foreach (var nic in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (nic.OperationalStatus != OperationalStatus.Up) continue;
                if (nic.NetworkInterfaceType is NetworkInterfaceType.Loopback or NetworkInterfaceType.Tunnel) continue;
                try
                {
                    var stats = nic.GetIPStatistics();
                    rx += stats.BytesReceived;
                    tx += stats.BytesSent;
                }
                catch { }
            }
        }
        catch { return; }

        var now = DateTime.UtcNow;
        if (_primed)
        {
            double seconds = (now - _lastNetSample).TotalSeconds;
            if (seconds > 0.2)
            {
                DownloadBytesPerSec = Math.Max(0, (rx - _lastRx) / seconds);
                UploadBytesPerSec = Math.Max(0, (tx - _lastTx) / seconds);
            }
        }

        _lastRx = rx; _lastTx = tx; _lastNetSample = now;
    }
}
