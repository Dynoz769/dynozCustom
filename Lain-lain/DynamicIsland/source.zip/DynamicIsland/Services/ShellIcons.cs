using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace DynamicIsland.Services;

/// <summary>Gets the Windows icon for a file, folder or running app.</summary>
internal static class ShellIcons
{
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    private struct SHFILEINFO
    {
        public IntPtr hIcon;
        public int iIcon;
        public uint dwAttributes;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)] public string szDisplayName;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 80)] public string szTypeName;
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SHGetFileInfo(string path, uint attributes, ref SHFILEINFO info, uint size, uint flags);

    [DllImport("user32.dll")]
    private static extern bool DestroyIcon(IntPtr hIcon);

    private const uint SHGFI_ICON = 0x100;
    private const uint SHGFI_LARGEICON = 0x0;

    private static readonly Dictionary<string, ImageSource?> PathCache = new(StringComparer.OrdinalIgnoreCase);
    private static readonly Dictionary<string, ImageSource?> AppCache = new(StringComparer.OrdinalIgnoreCase);

    public static ImageSource? ForPath(string path)
    {
        if (PathCache.TryGetValue(path, out var cached)) return cached;

        ImageSource? result = null;
        var info = new SHFILEINFO();
        try
        {
            var ok = SHGetFileInfo(path, 0, ref info, (uint)Marshal.SizeOf<SHFILEINFO>(), SHGFI_ICON | SHGFI_LARGEICON);
            if (ok != IntPtr.Zero && info.hIcon != IntPtr.Zero)
            {
                var source = Imaging.CreateBitmapSourceFromHIcon(info.hIcon, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
                source.Freeze();
                result = source;
            }
        }
        catch { /* no icon */ }
        finally
        {
            if (info.hIcon != IntPtr.Zero) DestroyIcon(info.hIcon);
        }

        PathCache[path] = result;
        return result;
    }

    /// <summary>
    /// Icon for the app that's playing media. Works for normal desktop apps
    /// (e.g. "Spotify.exe", "chrome.exe"); Store apps fall back to no icon.
    /// </summary>
    public static ImageSource? ForApp(string appId)
    {
        if (string.IsNullOrEmpty(appId) || appId.Contains('!')) return null;
        if (AppCache.TryGetValue(appId, out var cached)) return cached;

        ImageSource? icon = null;
        try
        {
            string processName = Path.GetFileNameWithoutExtension(appId);
            foreach (var process in Process.GetProcessesByName(processName))
            {
                try
                {
                    string? file = process.MainModule?.FileName;
                    if (file != null && icon == null) icon = ForPath(file);
                }
                catch { /* access denied for elevated apps */ }
                finally { process.Dispose(); }
            }
        }
        catch { }

        AppCache[appId] = icon;
        return icon;
    }

    /// <summary>A readable name for the app that's playing media.</summary>
    public static string FriendlyAppName(string appId)
    {
        if (string.IsNullOrEmpty(appId)) return "";
        string id = appId.ToLowerInvariant();

        (string key, string name)[] known =
        {
            ("spotify", "Spotify"), ("msedge", "Microsoft Edge"), ("chrome", "Google Chrome"),
            ("firefox", "Firefox"), ("brave", "Brave"), ("opera", "Opera"), ("vivaldi", "Vivaldi"),
            ("zunemusic", "Media Player"), ("zunevideo", "Movies & TV"), ("vlc", "VLC"),
            ("applemusic", "Apple Music"), ("itunes", "iTunes"), ("discord", "Discord"),
            ("tidal", "TIDAL"), ("deezer", "Deezer"), ("amazonmusic", "Amazon Music"),
            ("foobar", "foobar2000"), ("aimp", "AIMP"), ("musicbee", "MusicBee"),
        };
        foreach (var (key, name) in known)
            if (id.Contains(key)) return name;

        string s = appId;
        int bang = s.IndexOf('!');
        if (bang >= 0) s = s[..bang];
        int underscore = s.IndexOf('_');
        if (underscore > 0) s = s[..underscore];
        if (s.EndsWith(".exe", StringComparison.OrdinalIgnoreCase)) s = s[..^4];
        int dot = s.LastIndexOf('.');
        if (dot >= 0 && dot < s.Length - 1) s = s[(dot + 1)..];
        return s.Length > 0 ? char.ToUpperInvariant(s[0]) + s[1..] : appId;
    }
}
