using NAudio.CoreAudioApi;

namespace DynamicIsland.Services;

/// <summary>Watches the speaker volume and lets the island change it.</summary>
public sealed class VolumeService
{
    private MMDeviceEnumerator? _enumerator;
    private MMDevice? _device;
    private string? _deviceId;

    /// <summary>Raised on a background thread: (volume 0-1, muted).</summary>
    public event Action<float, bool>? VolumeChanged;

    public void Start()
    {
        try
        {
            _enumerator = new MMDeviceEnumerator();
            CheckDefaultDevice();
        }
        catch { /* no audio device */ }
    }

    /// <summary>Call regularly: follows you when you switch speakers / headphones.</summary>
    public void CheckDefaultDevice()
    {
        if (_enumerator == null) return;
        try
        {
            var device = _enumerator.GetDefaultAudioEndpoint(DataFlow.Render, Role.Multimedia);
            if (device.ID == _deviceId) return;

            if (_device != null)
                _device.AudioEndpointVolume.OnVolumeNotification -= OnNotification;

            _device = device;
            _deviceId = device.ID;
            _device.AudioEndpointVolume.OnVolumeNotification += OnNotification;
        }
        catch { }
    }

    public void Adjust(float delta)
    {
        if (_device == null) return;
        try
        {
            var endpoint = _device.AudioEndpointVolume;
            float level = Math.Clamp(endpoint.MasterVolumeLevelScalar + delta, 0f, 1f);
            endpoint.MasterVolumeLevelScalar = level;
            if (level > 0 && endpoint.Mute) endpoint.Mute = false;
        }
        catch { }
    }

    private void OnNotification(AudioVolumeNotificationData data)
        => VolumeChanged?.Invoke(data.MasterVolume, data.Muted);
}
