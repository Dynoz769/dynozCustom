using System.Diagnostics;
using System.Text.Json;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using DynamicIsland.Services;
using Microsoft.Win32;

namespace DynamicIsland;

public partial class MainWindow : Window
{
    // ================================================================
    //  Look & feel (tweak these)
    // ================================================================
    private const double CompactIdleWidth = 190;
    private const double CompactActivityWidth = 222;
    private const double CompactHeight = 34;
    private const double PopupWidth = 340, PopupHeight = 40;
    private const double ExpandedWidth = 440, ExpandedHeight = 200;
    private const double MaxCornerRadius = 40;
    private const double TopMargin = 6;
    private const float VolumeStep = 0.02f;              // per mouse-wheel notch
    private const double SpringGrow = 0.32;               // bounce when opening (0 = none)
    private const double SpringShrink = 0.18;             // bounce when closing

    private static readonly SolidColorBrush White = Freeze(Colors.White);
    private static readonly SolidColorBrush Dim = Freeze(Color.FromArgb(0x80, 0xFF, 0xFF, 0xFF));
    private static readonly SolidColorBrush Orange = Freeze(Color.FromRgb(0xFF, 0x9F, 0x0A));
    private static readonly SolidColorBrush Green = Freeze(Color.FromRgb(0x30, 0xD1, 0x58));
    private static readonly SolidColorBrush Red = Freeze(Color.FromRgb(0xFF, 0x45, 0x3A));
    private static readonly SolidColorBrush Chip = Freeze(Color.FromRgb(0x2C, 0x2C, 0x2E));
    private static readonly SolidColorBrush TileHover = Freeze(Color.FromArgb(0x22, 0xFF, 0xFF, 0xFF));

    private enum IslandMode { Compact, Popup, Expanded }
    private enum Tab { Media, Tools, Tray, Stats }
    private enum TimerState { Idle, Running, Paused }

    // ---- services ----
    private readonly MediaService _media;
    private readonly VolumeService _volume = new();
    private readonly PowerService _power;
    private readonly NetworkService _network;
    private readonly CapsLockWatcher _caps;
    private readonly SystemMonitor _monitor = new();

    // ---- timers ----
    private readonly DispatcherTimer _fastTick = new() { Interval = TimeSpan.FromMilliseconds(100) };
    private readonly DispatcherTimer _slowTick = new() { Interval = TimeSpan.FromSeconds(1) };
    private readonly DispatcherTimer _collapseTimer = new() { Interval = TimeSpan.FromMilliseconds(300) };
    private readonly DispatcherTimer _expandTimer = new() { Interval = TimeSpan.FromMilliseconds(140) };
    private readonly DispatcherTimer _popupTimer = new();
    private readonly DispatcherTimer _dragTimer = new();

    // ---- island state ----
    private IntPtr _hwnd;
    private IslandMode _mode = IslandMode.Compact;
    private double _targetWidth = CompactIdleWidth, _targetHeight = CompactHeight;
    private bool _hover, _dragActive, _draggingOut, _popupActive, _compactActivity;
    private bool _hiddenForFullscreen, _seeking;
    private bool? _equalizerAnimating;
    private Tab _tab = Tab.Media;
    private SolidColorBrush _accent = Green;
    private int _lastBatteryPercent = -1;
    private DateTime _volumeHintUntil;

    // ---- timer & stopwatch ----
    private TimerState _timerState = TimerState.Idle;
    private TimeSpan _timerDuration = TimeSpan.FromMinutes(5);
    private TimeSpan _timerLeft = TimeSpan.FromMinutes(5);
    private DateTime _timerEndsAt;
    private readonly Stopwatch _stopwatch = new();
    private int _lapCount;
    private TimeSpan _lastLapAt;

    // ---- file tray ----
    private readonly List<string> _tray = new();
    private static readonly string DataFolder =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "DynamicIsland");
    private static readonly string TrayFile = Path.Combine(DataFolder, "tray.json");

    public MainWindow()
    {
        InitializeComponent();
        PositionWindow();

        _media = new MediaService(Dispatcher);
        _media.StateChanged += UpdateMediaView;
        _media.TrackChanged += OnTrackChanged;

        _power = new PowerService(Dispatcher);
        _power.PluggedChanged += OnPluggedChanged;
        _power.PercentChanged += OnBatteryPercentChanged;

        _network = new NetworkService(Dispatcher);
        _network.Changed += OnNetworkChanged;

        _volume.VolumeChanged += (level, muted) => Dispatcher.InvokeAsync(() => OnVolumeChanged(level, muted));

        _caps = new CapsLockWatcher(Dispatcher);
        _caps.Changed += OnCapsLockChanged;

        _fastTick.Tick += (_, _) => OnFastTick();
        _slowTick.Tick += (_, _) => OnSlowTick();
        _collapseTimer.Tick += (_, _) =>
        {
            _collapseTimer.Stop();
            if (Island.IsMouseOver || _seeking || _draggingOut) return;
            _hover = false;
            UpdateMode();
        };
        _expandTimer.Tick += (_, _) =>
        {
            _expandTimer.Stop();
            if (!Island.IsMouseOver) return;
            _hover = true;
            UpdateMode();
        };
        _popupTimer.Tick += (_, _) =>
        {
            _popupTimer.Stop();
            _popupActive = false;
            UpdateMode();
        };
        _dragTimer.Tick += (_, _) =>
        {
            _dragTimer.Stop();
            _dragActive = false;
            if (!Island.IsMouseOver) _hover = false;
            UpdateMode();
        };

        StartupMenuItem.IsChecked = IsStartupEnabled();
        LoadTray();
        RebuildTray();
        SelectTab(Tab.Media);
        UpdateMediaView();
        UpdateTimerUi();
        UpdateStopwatchUi();
        UpdateClock();
        UpdateBattery();
        UpdateCompact();

        SourceInitialized += (_, _) =>
        {
            _hwnd = new WindowInteropHelper(this).Handle;
            Native.MakeOverlay(_hwnd);
            try { _caps.Start(); } catch { /* hook not allowed: Caps Lock alerts just won't show */ }
        };

        Loaded += async (_, _) =>
        {
            _volume.Start();
            _power.Start();
            _network.Start();
            _monitor.Sample();
            _lastBatteryPercent = _power.Percent;
            _fastTick.Start();
            _slowTick.Start();
            await _media.StartAsync();
        };

        Closed += (_, _) =>
        {
            _caps.Dispose();
            SaveTray();
        };
    }

    private static SolidColorBrush Freeze(Color c)
    {
        var b = new SolidColorBrush(c);
        b.Freeze();
        return b;
    }

    // ================================================================
    //  Ticks
    // ================================================================

    private void OnFastTick()
    {
        UpdateClock();
        UpdateTimer();
        UpdateStopwatchUi();
        UpdateSeekBar();
        UpdateCompact();
    }

    private void OnSlowTick()
    {
        _monitor.Sample();
        UpdateStats();
        _volume.CheckDefaultDevice();
        PositionWindow();

        bool fullscreen = HideFullscreenMenuItem.IsChecked && Native.IsForegroundFullscreen(_hwnd);
        if (fullscreen != _hiddenForFullscreen)
        {
            _hiddenForFullscreen = fullscreen;
            Visibility = fullscreen ? Visibility.Hidden : Visibility.Visible;
        }

        if (!_hiddenForFullscreen && _hwnd != IntPtr.Zero) Native.KeepOnTop(_hwnd);
    }

    private void PositionWindow()
    {
        double left = Math.Round((SystemParameters.PrimaryScreenWidth - Width) / 2);
        if (Math.Abs(Left - left) > 0.5) Left = left;
        if (Math.Abs(Top - TopMargin) > 0.5) Top = TopMargin;
    }

    private void UpdateClock()
    {
        var now = DateTime.Now;
        CompactClock.Text = now.ToString("h:mm");
        ExpandedTime.Text = now.ToString("h:mm tt");
        if (now >= _volumeHintUntil) ExpandedDate.Text = now.ToString("ddd d MMM");
    }

    // ================================================================
    //  Island shape: compact / pop-up / expanded
    // ================================================================

    private void UpdateMode()
    {
        IslandMode target = (_hover || _dragActive || _draggingOut) ? IslandMode.Expanded
                          : _popupActive ? IslandMode.Popup
                          : IslandMode.Compact;

        double w, h;
        switch (target)
        {
            case IslandMode.Expanded: w = ExpandedWidth; h = ExpandedHeight; break;
            case IslandMode.Popup: w = PopupWidth; h = PopupHeight; break;
            default: w = _compactActivity ? CompactActivityWidth : CompactIdleWidth; h = CompactHeight; break;
        }

        bool modeChanged = target != _mode;
        if (!modeChanged && w == _targetWidth && h == _targetHeight) return;

        bool growing = w * h > _targetWidth * _targetHeight;
        _mode = target;
        _targetWidth = w;
        _targetHeight = h;

        var ease = new BackEase { Amplitude = growing ? SpringGrow : SpringShrink, EasingMode = EasingMode.EaseOut };
        var duration = TimeSpan.FromMilliseconds(growing ? 480 : 400);
        Island.BeginAnimation(WidthProperty, new DoubleAnimation(w, duration) { EasingFunction = ease });
        Island.BeginAnimation(HeightProperty, new DoubleAnimation(h, duration) { EasingFunction = ease });

        if (modeChanged)
        {
            Fade(CompactPanel, target == IslandMode.Compact);
            Fade(PopupPanel, target == IslandMode.Popup);
            Fade(ExpandedPanel, target == IslandMode.Expanded);
        }
    }

    private static void Fade(UIElement element, bool show)
    {
        element.IsHitTestVisible = show;
        element.BeginAnimation(OpacityProperty, new DoubleAnimation(show ? 1 : 0, TimeSpan.FromMilliseconds(show ? 220 : 90))
        {
            BeginTime = TimeSpan.FromMilliseconds(show ? 110 : 0)
        });
    }

    private void Island_SizeChanged(object sender, SizeChangedEventArgs e)
        => Island.CornerRadius = new CornerRadius(Math.Min(Island.ActualHeight / 2, MaxCornerRadius));

    private void Island_MouseEnter(object sender, MouseEventArgs e)
    {
        _collapseTimer.Stop();
        if (_hover) return;
        // Small delay so it doesn't open when the mouse just passes by
        _expandTimer.Stop();
        _expandTimer.Start();
    }

    private void Island_MouseLeave(object sender, MouseEventArgs e)
    {
        _expandTimer.Stop();
        _collapseTimer.Stop();
        _collapseTimer.Start();
    }

    private void Island_PreviewMouseWheel(object sender, MouseWheelEventArgs e)
    {
        if (_mode == IslandMode.Expanded && _tab == Tab.Tray) return; // let the file tray scroll
        _volume.Adjust(e.Delta > 0 ? VolumeStep : -VolumeStep);
        e.Handled = true;
    }

    // ================================================================
    //  Compact pill content ("live activities")
    // ================================================================

    private void UpdateCompact()
    {
        CompactClock.Visibility = Visibility.Collapsed;
        CompactArt.Visibility = Visibility.Collapsed;
        CompactGlyph.Visibility = Visibility.Collapsed;
        CompactRightText.Visibility = Visibility.Collapsed;
        bool showEqualizer = false;
        bool activity = true;

        if (_timerState != TimerState.Idle)
        {
            ShowCompactGlyph("", Orange);
            ShowCompactText(FormatTime(TimerRemaining), Orange);
        }
        else if (_stopwatch.IsRunning)
        {
            ShowCompactGlyph("", Green);
            ShowCompactText(FormatTime(_stopwatch.Elapsed), White);
        }
        else if (_media.HasSession && _media.IsPlaying)
        {
            if (_media.Art != null) CompactArt.Visibility = Visibility.Visible;
            else ShowCompactGlyph("", _accent);
            showEqualizer = true;
        }
        else
        {
            activity = false;
            CompactClock.Visibility = Visibility.Visible;
            if (_power.HasBattery)
            {
                int pct = _power.Percent;
                ShowCompactText(_power.IsCharging ? $"⚡{pct}%" : $"{pct}%",
                                pct <= 20 && !_power.IsCharging ? Red : White);
            }
        }

        Equalizer.Visibility = showEqualizer ? Visibility.Visible : Visibility.Collapsed;
        SetEqualizerAnimating(showEqualizer);

        if (activity != _compactActivity)
        {
            _compactActivity = activity;
            if (_mode == IslandMode.Compact) UpdateMode();
        }
    }

    private void ShowCompactGlyph(string glyph, Brush brush)
    {
        CompactGlyph.Text = glyph;
        CompactGlyph.Foreground = brush;
        CompactGlyph.Visibility = Visibility.Visible;
    }

    private void ShowCompactText(string text, Brush brush)
    {
        CompactRightText.Text = text;
        CompactRightText.Foreground = brush;
        CompactRightText.Visibility = Visibility.Visible;
    }

    private void SetEqualizerAnimating(bool animate)
    {
        if (_equalizerAnimating == animate) return;
        _equalizerAnimating = animate;

        System.Windows.Shapes.Rectangle[] bars = { Bar1, Bar2, Bar3, Bar4 };
        int[] speeds = { 380, 520, 300, 450 };
        for (int i = 0; i < bars.Length; i++)
        {
            var scale = (ScaleTransform)bars[i].RenderTransform;
            if (animate)
            {
                scale.BeginAnimation(ScaleTransform.ScaleYProperty,
                    new DoubleAnimation(0.25, 1.0, TimeSpan.FromMilliseconds(speeds[i]))
                    {
                        AutoReverse = true,
                        RepeatBehavior = RepeatBehavior.Forever,
                        EasingFunction = new SineEase { EasingMode = EasingMode.EaseInOut }
                    });
            }
            else
            {
                scale.BeginAnimation(ScaleTransform.ScaleYProperty, null);
                scale.ScaleY = 0.3;
            }
        }
    }

    // ================================================================
    //  Pop-ups
    // ================================================================

    private void ShowPopup(string glyph, Brush glyphBrush, string title, string? subtitle = null,
                           string? right = null, double? progress = null, Brush? progressBrush = null,
                           double seconds = 2, ImageSource? image = null)
    {
        if (image != null)
        {
            PopupImage.Background = new ImageBrush(image) { Stretch = Stretch.UniformToFill };
            PopupImage.Visibility = Visibility.Visible;
            PopupGlyph.Visibility = Visibility.Collapsed;
        }
        else
        {
            PopupImage.Visibility = Visibility.Collapsed;
            PopupGlyph.Visibility = Visibility.Visible;
            PopupGlyph.Text = glyph;
            PopupGlyph.Foreground = glyphBrush;
        }

        PopupTitle.Text = title;
        PopupSubtitle.Text = subtitle ?? "";
        PopupSubtitle.Visibility = string.IsNullOrEmpty(subtitle) ? Visibility.Collapsed : Visibility.Visible;
        PopupRight.Text = right ?? "";

        if (progress is double p)
        {
            PopupBar.Visibility = Visibility.Visible;
            PopupBarFill.Background = progressBrush ?? White;
            AnimateBar(PopupBarFill, p);
        }
        else
        {
            PopupBar.Visibility = Visibility.Collapsed;
        }

        _popupTimer.Stop();
        _popupTimer.Interval = TimeSpan.FromSeconds(seconds);
        _popupTimer.Start();
        _popupActive = true;
        UpdateMode();
    }

    private static void SetBar(Border fill, double fraction)
    {
        var scale = (ScaleTransform)fill.RenderTransform;
        scale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
        scale.ScaleX = Math.Clamp(fraction, 0, 1);
    }

    private static void AnimateBar(Border fill, double fraction)
        => fill.RenderTransform.BeginAnimation(ScaleTransform.ScaleXProperty,
               new DoubleAnimation(Math.Clamp(fraction, 0, 1), TimeSpan.FromMilliseconds(180))
               {
                   EasingFunction = new CubicEase { EasingMode = EasingMode.EaseOut }
               });

    private void OnVolumeChanged(float level, bool muted)
    {
        int pct = (int)Math.Round(level * 100);

        // While open, show the level in the header instead of a pop-up
        if (_mode == IslandMode.Expanded)
        {
            ExpandedDate.Text = muted ? "Volume muted" : $"Volume {pct}%";
            _volumeHintUntil = DateTime.Now.AddSeconds(1.5);
            return;
        }

        string glyph = muted || pct == 0 ? "" : pct < 34 ? "" : pct < 67 ? "" : "";
        ShowPopup(glyph, White, "Volume", right: muted ? "Muted" : $"{pct}%",
                  progress: muted ? 0 : level, seconds: 1.6);
    }

    private void OnCapsLockChanged(bool on)
        => ShowPopup("", on ? Green : Dim, "Caps Lock", right: on ? "On" : "Off", seconds: 1.3);

    private void OnNetworkChanged(bool connected, string name, bool wifi)
    {
        if (connected)
            ShowPopup(wifi ? "" : "", Green, string.IsNullOrEmpty(name) ? "Connected" : name,
                      wifi ? "Wi-Fi connected" : "Ethernet connected", seconds: 2.5);
        else
            ShowPopup("", Red, "Disconnected", "No internet connection", seconds: 3);
    }

    private void OnTrackChanged()
    {
        if (!_media.IsPlaying || _hover) return;
        ShowPopup("", _accent, _media.Title, _media.Artist, seconds: 2.5, image: _media.Art);
    }

    private void OnPluggedChanged()
    {
        UpdateBattery();
        if (!_power.HasBattery) return;

        int pct = _power.Percent;
        if (_power.IsPluggedIn)
            ShowPopup("", Green, "Charging", right: $"{pct}%", progress: pct / 100.0, progressBrush: Green, seconds: 2.5);
        else
            ShowPopup(BatteryGlyph(pct), White, "On battery", right: $"{pct}%", progress: pct / 100.0,
                      progressBrush: pct <= 20 ? Red : White, seconds: 2.5);
    }

    private void OnBatteryPercentChanged()
    {
        UpdateBattery();
        if (!_power.HasBattery) return;

        int pct = _power.Percent;
        int last = _lastBatteryPercent;
        _lastBatteryPercent = pct;
        if (last < 0) return;

        if (!_power.IsPluggedIn && ((last > 20 && pct <= 20) || (last > 10 && pct <= 10)))
            ShowPopup(BatteryGlyph(pct), Red, "Low battery", "Plug in your charger", $"{pct}%", pct / 100.0, Red, 5);
        else if (_power.IsPluggedIn && last < 100 && pct >= 100)
            ShowPopup("", Green, "Fully charged", right: "100%", progress: 1, progressBrush: Green, seconds: 3);
    }

    private static string BatteryGlyph(int pct)
        => pct >= 95 ? "" : ((char)(0xE850 + Math.Clamp(pct / 10, 0, 9))).ToString();

    // ================================================================
    //  Tabs
    // ================================================================

    private void Tab_Click(object sender, RoutedEventArgs e)
    {
        if (sender is Button { Tag: string tag } && Enum.TryParse(tag, out Tab tab))
            SelectTab(tab);
    }

    private void SelectTab(Tab tab)
    {
        _tab = tab;
        MediaView.Visibility = tab == Tab.Media ? Visibility.Visible : Visibility.Collapsed;
        ToolsView.Visibility = tab == Tab.Tools ? Visibility.Visible : Visibility.Collapsed;
        TrayView.Visibility = tab == Tab.Tray ? Visibility.Visible : Visibility.Collapsed;
        StatsView.Visibility = tab == Tab.Stats ? Visibility.Visible : Visibility.Collapsed;

        TabMedia.Foreground = tab == Tab.Media ? White : Dim;
        TabTools.Foreground = tab == Tab.Tools ? White : Dim;
        TabTray.Foreground = tab == Tab.Tray ? White : Dim;
        TabStats.Foreground = tab == Tab.Stats ? White : Dim;
    }

    // ================================================================
    //  Media
    // ================================================================

    private void UpdateMediaView()
    {
        bool has = _media.HasSession;

        TitleText.Text = !has ? "Nothing playing"
                       : string.IsNullOrWhiteSpace(_media.Title) ? "Unknown title" : _media.Title;
        ArtistText.Text = has ? _media.Artist : "Play something in Spotify, YouTube or any media app";

        if (_media.Art != null)
        {
            var brush = new ImageBrush(_media.Art) { Stretch = Stretch.UniformToFill };
            ArtBorder.Background = brush;
            CompactArt.Background = brush;
            ArtPlaceholder.Visibility = Visibility.Collapsed;
        }
        else
        {
            ArtBorder.Background = Chip;
            CompactArt.Background = null;
            ArtPlaceholder.Visibility = Visibility.Visible;
        }

        string appName = ShellIcons.FriendlyAppName(_media.AppId);
        AppName.Text = appName;
        AppIcon.Source = has ? ShellIcons.ForApp(_media.AppId) : null;
        AppIcon.Visibility = AppIcon.Source != null ? Visibility.Visible : Visibility.Collapsed;
        AppLine.Visibility = has && appName.Length > 0 ? Visibility.Visible : Visibility.Collapsed;

        PlayPauseButton.Content = _media.IsPlaying ? "" : "";
        PrevButton.IsEnabled = PlayPauseButton.IsEnabled = NextButton.IsEnabled = has;

        _accent = Freeze(_media.Accent);
        SeekFill.Background = _accent;
        foreach (var bar in new[] { Bar1, Bar2, Bar3, Bar4 }) bar.Fill = _accent;

        SeekRow.Visibility = _media.HasTimeline ? Visibility.Visible : Visibility.Hidden;
        UpdateSeekBar();
        UpdateCompact();
    }

    private void UpdateSeekBar()
    {
        if (_seeking || !_media.HasTimeline) return;
        var pos = _media.Position;
        var dur = _media.Duration;
        SetBar(SeekFill, pos.TotalSeconds / dur.TotalSeconds);
        ElapsedText.Text = FormatTime(pos);
        RemainingText.Text = "-" + FormatTime(dur - pos);
    }

    private async void Prev_Click(object sender, RoutedEventArgs e) => await _media.PreviousAsync();
    private async void PlayPause_Click(object sender, RoutedEventArgs e) => await _media.TogglePlayPauseAsync();
    private async void Next_Click(object sender, RoutedEventArgs e) => await _media.NextAsync();

    private void SeekTrack_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (!_media.HasTimeline) return;
        _seeking = true;
        SeekTrack.CaptureMouse();
        PreviewSeek(e.GetPosition(SeekTrack).X);
        e.Handled = true;
    }

    private void SeekTrack_MouseMove(object sender, MouseEventArgs e)
    {
        if (_seeking) PreviewSeek(e.GetPosition(SeekTrack).X);
    }

    private async void SeekTrack_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        if (!_seeking) return;
        double fraction = SeekFraction(e.GetPosition(SeekTrack).X);
        _seeking = false;
        SeekTrack.ReleaseMouseCapture();
        await _media.SeekAsync(TimeSpan.FromTicks((long)(fraction * _media.Duration.Ticks)));
        UpdateSeekBar();
    }

    private double SeekFraction(double x)
        => SeekTrack.ActualWidth > 0 ? Math.Clamp(x / SeekTrack.ActualWidth, 0, 1) : 0;

    private void PreviewSeek(double x)
    {
        double fraction = SeekFraction(x);
        var pos = TimeSpan.FromTicks((long)(fraction * _media.Duration.Ticks));
        SetBar(SeekFill, fraction);
        ElapsedText.Text = FormatTime(pos);
        RemainingText.Text = "-" + FormatTime(_media.Duration - pos);
    }

    // ================================================================
    //  Timer
    // ================================================================

    private TimeSpan TimerRemaining => _timerState == TimerState.Running
        ? (_timerEndsAt > DateTime.Now ? _timerEndsAt - DateTime.Now : TimeSpan.Zero)
        : _timerLeft;

    private void TimerPreset_Click(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { Tag: string tag } || !int.TryParse(tag, out int minutes)) return;
        _timerDuration = TimeSpan.FromMinutes(minutes);
        _timerLeft = _timerDuration;
        _timerState = TimerState.Idle;
        UpdateTimerUi();
    }

    private void TimerStart_Click(object sender, RoutedEventArgs e)
    {
        if (_timerState == TimerState.Running)
        {
            _timerLeft = TimerRemaining;
            _timerState = TimerState.Paused;
        }
        else
        {
            if (_timerLeft <= TimeSpan.Zero) _timerLeft = _timerDuration;
            _timerEndsAt = DateTime.Now + _timerLeft;
            _timerState = TimerState.Running;
        }
        UpdateTimerUi();
    }

    private void TimerReset_Click(object sender, RoutedEventArgs e)
    {
        _timerState = TimerState.Idle;
        _timerLeft = _timerDuration;
        UpdateTimerUi();
    }

    private void UpdateTimer()
    {
        if (_timerState == TimerState.Running && TimerRemaining <= TimeSpan.Zero)
        {
            _timerState = TimerState.Idle;
            _timerLeft = _timerDuration;
            Native.Beep();
            ShowPopup("", Orange, "Timer done", $"{_timerDuration.TotalMinutes:0} minute timer", seconds: 6);
        }
        UpdateTimerUi();
    }

    private void UpdateTimerUi()
    {
        TimerText.Text = FormatTime(TimerRemaining);
        TimerStartButton.Content = _timerState == TimerState.Running ? "" : "";
    }

    // ================================================================
    //  Stopwatch
    // ================================================================

    private void StopwatchStart_Click(object sender, RoutedEventArgs e)
    {
        if (_stopwatch.IsRunning) _stopwatch.Stop();
        else _stopwatch.Start();
        UpdateStopwatchUi();
    }

    private void LapReset_Click(object sender, RoutedEventArgs e)
    {
        if (_stopwatch.IsRunning)
        {
            var now = _stopwatch.Elapsed;
            _lapCount++;
            LapText.Text = $"Lap {_lapCount}   {FormatStopwatch(now - _lastLapAt)}";
            _lastLapAt = now;
        }
        else
        {
            _stopwatch.Reset();
            _lapCount = 0;
            _lastLapAt = TimeSpan.Zero;
            LapText.Text = "Press start";
        }
        UpdateStopwatchUi();
    }

    private void UpdateStopwatchUi()
    {
        StopwatchText.Text = FormatStopwatch(_stopwatch.Elapsed);
        StopwatchStartButton.Content = _stopwatch.IsRunning ? "" : "";
        LapResetButton.Content = _stopwatch.IsRunning ? "" : ""; // flag = lap, arrow = reset
    }

    // ================================================================
    //  File tray
    // ================================================================

    private void Island_DragOver(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (_draggingOut || !e.Data.GetDataPresent(DataFormats.FileDrop))
        {
            e.Effects = DragDropEffects.None;
            return;
        }

        e.Effects = DragDropEffects.Copy;
        if (_tab != Tab.Tray) SelectTab(Tab.Tray);

        _dragActive = true;
        _dragTimer.Stop();
        _dragTimer.Interval = TimeSpan.FromMilliseconds(450); // closes shortly after the drag leaves
        _dragTimer.Start();
        UpdateMode();
    }

    private void Island_Drop(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (_draggingOut) return;

        if (e.Data.GetData(DataFormats.FileDrop) is string[] files)
            AddToTray(files);

        // Stay open a moment so you can see the files land
        _dragTimer.Stop();
        _dragTimer.Interval = TimeSpan.FromMilliseconds(1500);
        _dragTimer.Start();
    }

    private void AddToTray(IEnumerable<string> paths)
    {
        foreach (var path in paths)
            if (!_tray.Contains(path, StringComparer.OrdinalIgnoreCase))
                _tray.Add(path);
        SaveTray();
        RebuildTray();
    }

    private void RemoveFromTray(string path)
    {
        _tray.RemoveAll(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase));
        SaveTray();
        RebuildTray();
    }

    private void TrayClear_Click(object sender, RoutedEventArgs e)
    {
        _tray.Clear();
        SaveTray();
        RebuildTray();
    }

    private void RebuildTray()
    {
        TrayItems.Children.Clear();
        foreach (var path in _tray) TrayItems.Children.Add(CreateTrayTile(path));

        bool empty = _tray.Count == 0;
        TrayEmpty.Visibility = empty ? Visibility.Visible : Visibility.Collapsed;
        TrayHeader.Visibility = empty ? Visibility.Collapsed : Visibility.Visible;
        TrayCount.Text = _tray.Count == 1 ? "1 item" : $"{_tray.Count} items";
    }

    private FrameworkElement CreateTrayTile(string path)
    {
        string name = Path.GetFileName(path.TrimEnd('\\', '/'));
        if (string.IsNullOrEmpty(name)) name = path;

        var stack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
        stack.Children.Add(new Image
        {
            Width = 32,
            Height = 32,
            Source = ShellIcons.ForPath(path),
            HorizontalAlignment = HorizontalAlignment.Center
        });
        stack.Children.Add(new TextBlock
        {
            Text = name,
            Foreground = White,
            FontSize = 11,
            TextAlignment = TextAlignment.Center,
            TextTrimming = TextTrimming.CharacterEllipsis,
            Margin = new Thickness(4, 5, 4, 0)
        });

        var tile = new Border
        {
            Width = 78,
            Height = 68,
            Margin = new Thickness(1),
            CornerRadius = new CornerRadius(14),
            Background = Brushes.Transparent,
            Child = stack,
            ToolTip = path,
            Cursor = Cursors.Hand
        };

        tile.MouseEnter += (_, _) => tile.Background = TileHover;
        tile.MouseLeave += (_, _) => tile.Background = Brushes.Transparent;

        Point? dragStart = null;
        tile.MouseLeftButtonDown += (_, e) =>
        {
            if (e.ClickCount == 2)
            {
                OpenPath(path);
                dragStart = null;
                e.Handled = true;
                return;
            }
            dragStart = e.GetPosition(tile);
        };
        tile.MouseLeftButtonUp += (_, _) => dragStart = null;
        tile.MouseMove += (_, e) =>
        {
            if (dragStart is not Point start || e.LeftButton != MouseButtonState.Pressed) return;
            var now = e.GetPosition(tile);
            if (Math.Abs(now.X - start.X) < SystemParameters.MinimumHorizontalDragDistance &&
                Math.Abs(now.Y - start.Y) < SystemParameters.MinimumVerticalDragDistance) return;

            dragStart = null;
            DragOut(tile, path);
        };

        var menu = new ContextMenu();
        menu.Items.Add(CreateMenuItem("Open", () => OpenPath(path)));
        menu.Items.Add(CreateMenuItem("Show in folder", () => ShowInFolder(path)));
        menu.Items.Add(new Separator());
        menu.Items.Add(CreateMenuItem("Remove from tray", () => RemoveFromTray(path)));
        tile.ContextMenu = menu;

        return tile;
    }

    private static MenuItem CreateMenuItem(string header, Action action)
    {
        var item = new MenuItem { Header = header };
        item.Click += (_, _) => action();
        return item;
    }

    private void DragOut(DependencyObject source, string path)
    {
        _draggingOut = true;
        try
        {
            var data = new DataObject(DataFormats.FileDrop, new[] { path });
            DragDrop.DoDragDrop(source, data, DragDropEffects.Copy | DragDropEffects.Move | DragDropEffects.Link);
        }
        catch { }
        finally
        {
            _draggingOut = false;
            // If the file was moved somewhere else, drop it from the tray
            if (!File.Exists(path) && !Directory.Exists(path)) RemoveFromTray(path);
            _collapseTimer.Stop();
            _collapseTimer.Start();
        }
    }

    private static void OpenPath(string path)
    {
        try { Process.Start(new ProcessStartInfo(path) { UseShellExecute = true }); }
        catch { }
    }

    private static void ShowInFolder(string path)
    {
        try { Process.Start("explorer.exe", $"/select,\"{path}\""); }
        catch { }
    }

    private void LoadTray()
    {
        try
        {
            if (!File.Exists(TrayFile)) return;
            var saved = JsonSerializer.Deserialize<List<string>>(File.ReadAllText(TrayFile));
            if (saved == null) return;
            _tray.AddRange(saved.Where(p => File.Exists(p) || Directory.Exists(p)));
        }
        catch { }
    }

    private void SaveTray()
    {
        try
        {
            Directory.CreateDirectory(DataFolder);
            File.WriteAllText(TrayFile, JsonSerializer.Serialize(_tray));
        }
        catch { }
    }

    // ================================================================
    //  Stats
    // ================================================================

    private void UpdateStats()
    {
        double cpu = _monitor.CpuPercent;
        CpuText.Text = $"{cpu:0}%";
        CpuBar.Background = LevelBrush(cpu);
        AnimateBar(CpuBar, cpu / 100);

        double mem = _monitor.MemoryPercent;
        MemText.Text = $"{mem:0}%";
        MemDetail.Text = $"{_monitor.MemoryUsedGb:0.0} / {_monitor.MemoryTotalGb:0} GB";
        MemBar.Background = LevelBrush(mem);
        AnimateBar(MemBar, mem / 100);

        NetDownText.Text = "↓ " + FormatRate(_monitor.DownloadBytesPerSec);
        NetUpText.Text = "↑ " + FormatRate(_monitor.UploadBytesPerSec);

        UpdateBattery();
    }

    private void UpdateBattery()
    {
        if (!_power.HasBattery)
        {
            BatteryText.Text = "Plugged in";
            BatteryDetail.Text = "No battery";
            BatteryBarGrid.Visibility = Visibility.Hidden;
            return;
        }

        int pct = _power.Percent;
        BatteryText.Text = $"{pct}%";
        BatteryDetail.Text = _power.IsCharging ? "Charging" : _power.IsPluggedIn ? "Plugged in" : "On battery";
        BatteryBarGrid.Visibility = Visibility.Visible;
        BatteryBar.Background = _power.IsCharging ? Green : pct <= 20 ? Red : White;
        SetBar(BatteryBar, pct / 100.0);
    }

    private static Brush LevelBrush(double percent)
        => percent < 60 ? Green : percent < 85 ? Orange : Red;

    // ================================================================
    //  Formatting
    // ================================================================

    private static string FormatTime(TimeSpan t)
    {
        if (t < TimeSpan.Zero) t = TimeSpan.Zero;
        var s = TimeSpan.FromSeconds(Math.Floor(t.TotalSeconds));
        return s.TotalHours >= 1
            ? $"{(int)s.TotalHours}:{s.Minutes:00}:{s.Seconds:00}"
            : $"{(int)s.TotalMinutes}:{s.Seconds:00}";
    }

    private static string FormatStopwatch(TimeSpan t)
        => t.TotalHours >= 1
            ? $"{(int)t.TotalHours}:{t.Minutes:00}:{t.Seconds:00}"
            : $"{(int)t.TotalMinutes}:{t.Seconds:00}.{t.Milliseconds / 100}";

    private static string FormatRate(double bytesPerSecond)
        => bytesPerSecond >= 1024 * 1024
            ? $"{bytesPerSecond / (1024 * 1024):0.0} MB/s"
            : $"{bytesPerSecond / 1024:0} KB/s";

    // ================================================================
    //  Right-click menu
    // ================================================================

    private const string RunKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string RunValueName = "DynamicIsland";

    private static bool IsStartupEnabled()
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath);
            return key?.GetValue(RunValueName) != null;
        }
        catch { return false; }
    }

    private void StartupMenuItem_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            using var key = Registry.CurrentUser.OpenSubKey(RunKeyPath, writable: true)
                            ?? Registry.CurrentUser.CreateSubKey(RunKeyPath);
            if (StartupMenuItem.IsChecked)
                key.SetValue(RunValueName, $"\"{Environment.ProcessPath}\"");
            else
                key.DeleteValue(RunValueName, throwOnMissingValue: false);
        }
        catch { }
    }

    private void Exit_Click(object sender, RoutedEventArgs e) => Application.Current.Shutdown();
}
